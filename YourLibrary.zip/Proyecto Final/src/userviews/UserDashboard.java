
package userviews;

//import adminviews.devoluciones;
//import adminviews.libros;
//import adminviews.admins;
//import adminviews.principal;
//import adminviews.reportes;
//import adminviews.usuarios;
import java.awt.BorderLayout;
import java.awt.Color;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import javax.swing.JPanel;

public class UserDashboard extends javax.swing.JPanel {

    public UserDashboard() {
        initComponents();
        Initcontent();
        SetDate();
        InitStyles();
    }

    private void InitStyles(){
        MS.setForeground(Color.BLACK);
        me1.setForeground(Color.BLACK);
        me2.setForeground(Color.BLACK);
        despliegue.setBackground(Color.WHITE);
    }
    
    private void Initcontent(){
        ShowJPanelUcontext (new principal());
    }
    
    public void ShowJPanelUcontext (JPanel pl){
        pl.setSize(762, 428);
        pl.setLocation(0, 0);
        
        despliegue.removeAll();
        despliegue.add(pl, BorderLayout.CENTER);
        despliegue.revalidate();
        despliegue.repaint();
    }
    
    private void SetDate (){
        LocalDate now = LocalDate.now();
        Locale spanishLocale = new Locale("es", "COL");
        me2.setText(now.format(DateTimeFormatter.ofPattern("'Hoy es' EEEE dd 'de' MMMM 'de' yyyy", spanishLocale)));
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        MS = new javax.swing.JLabel();
        Menu = new javax.swing.JPanel();
        mmi = new javax.swing.JLabel();
        mml = new javax.swing.JLabel();
        reportes = new javax.swing.JButton();
        prestamos1 = new javax.swing.JButton();
        principal = new javax.swing.JButton();
        Devoluciones = new javax.swing.JButton();
        libros = new javax.swing.JButton();
        Encabezado = new javax.swing.JPanel();
        me1 = new javax.swing.JLabel();
        me2 = new javax.swing.JLabel();
        despliegue = new javax.swing.JPanel();

        setMaximumSize(new java.awt.Dimension(1044, 640));
        setMinimumSize(new java.awt.Dimension(1044, 640));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        MS.setBackground(new java.awt.Color(255, 255, 255));
        MS.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        MS.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        MS.setText("¡Debemos ♡ la lectura!");

        Menu.setBackground(new java.awt.Color(74, 162, 117));
        Menu.setPreferredSize(new java.awt.Dimension(270, 640));
        Menu.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        mmi.setFont(new java.awt.Font("Times New Roman", 3, 36)); // NOI18N
        mmi.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mmi.setText("YOURLibrary");
        Menu.add(mmi, new org.netbeans.lib.awtextra.AbsoluteConstraints(31, 59, -1, 46));

        mml.setFont(new java.awt.Font("Snap ITC", 1, 18)); // NOI18N
        mml.setText("------------------------------");
        Menu.add(mml, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 111, 243, -1));

        reportes.setBackground(new java.awt.Color(32, 64, 63));
        reportes.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        reportes.setForeground(new java.awt.Color(255, 255, 255));
        reportes.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\file-chart.png")); // NOI18N
        reportes.setText("Reportes");
        reportes.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 10, 0, 0, new java.awt.Color(49, 69, 73)));
        reportes.setBorderPainted(false);
        reportes.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        reportes.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        reportes.setIconTextGap(10);
        reportes.setMaximumSize(new java.awt.Dimension(75, 25));
        reportes.setPreferredSize(new java.awt.Dimension(75, 25));
        reportes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportesActionPerformed(evt);
            }
        });
        Menu.add(reportes, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 510, 270, 90));

        prestamos1.setBackground(new java.awt.Color(32, 64, 63));
        prestamos1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        prestamos1.setForeground(new java.awt.Color(255, 255, 255));
        prestamos1.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\calendar-plus.png")); // NOI18N
        prestamos1.setText("Préstamos");
        prestamos1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 10, 0, 0, new java.awt.Color(49, 69, 73)));
        prestamos1.setBorderPainted(false);
        prestamos1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        prestamos1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        prestamos1.setIconTextGap(10);
        prestamos1.setMaximumSize(new java.awt.Dimension(75, 25));
        prestamos1.setPreferredSize(new java.awt.Dimension(75, 25));
        prestamos1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prestamos1ActionPerformed(evt);
            }
        });
        Menu.add(prestamos1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 270, 90));

        principal.setBackground(new java.awt.Color(32, 64, 63));
        principal.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        principal.setForeground(new java.awt.Color(255, 255, 255));
        principal.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\home-outline.png")); // NOI18N
        principal.setText("Principal");
        principal.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 10, 0, 0, new java.awt.Color(49, 69, 73)));
        principal.setBorderPainted(false);
        principal.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        principal.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        principal.setIconTextGap(10);
        principal.setMaximumSize(new java.awt.Dimension(75, 25));
        principal.setPreferredSize(new java.awt.Dimension(75, 25));
        principal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                principalActionPerformed(evt);
            }
        });
        Menu.add(principal, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 270, 90));

        Devoluciones.setBackground(new java.awt.Color(32, 64, 63));
        Devoluciones.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        Devoluciones.setForeground(new java.awt.Color(255, 255, 255));
        Devoluciones.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\calendar-multiple-check.png")); // NOI18N
        Devoluciones.setText("Devoluciones");
        Devoluciones.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 10, 0, 0, new java.awt.Color(49, 69, 73)));
        Devoluciones.setBorderPainted(false);
        Devoluciones.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Devoluciones.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Devoluciones.setIconTextGap(10);
        Devoluciones.setMaximumSize(new java.awt.Dimension(75, 25));
        Devoluciones.setPreferredSize(new java.awt.Dimension(75, 25));
        Devoluciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DevolucionesActionPerformed(evt);
            }
        });
        Menu.add(Devoluciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 330, 270, 90));

        libros.setBackground(new java.awt.Color(32, 64, 63));
        libros.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        libros.setForeground(new java.awt.Color(255, 255, 255));
        libros.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\book-open-page-variant.png")); // NOI18N
        libros.setText("Libros");
        libros.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 10, 0, 0, new java.awt.Color(49, 69, 73)));
        libros.setBorderPainted(false);
        libros.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        libros.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        libros.setIconTextGap(10);
        libros.setMaximumSize(new java.awt.Dimension(75, 25));
        libros.setPreferredSize(new java.awt.Dimension(75, 25));
        libros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                librosActionPerformed(evt);
            }
        });
        Menu.add(libros, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 420, 270, 90));

        Encabezado.setBackground(new java.awt.Color(39, 195, 130));

        me1.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        me1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        me1.setText("Administrar/Control/Biblioteca");

        me2.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        me2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        me2.setText("Hoy es {dayname} {day} de {month} del {year}");

        javax.swing.GroupLayout EncabezadoLayout = new javax.swing.GroupLayout(Encabezado);
        Encabezado.setLayout(EncabezadoLayout);
        EncabezadoLayout.setHorizontalGroup(
            EncabezadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EncabezadoLayout.createSequentialGroup()
                .addGap(145, 145, 145)
                .addGroup(EncabezadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(me2, javax.swing.GroupLayout.PREFERRED_SIZE, 445, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(me1, javax.swing.GroupLayout.PREFERRED_SIZE, 445, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(184, 184, 184))
        );
        EncabezadoLayout.setVerticalGroup(
            EncabezadoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EncabezadoLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(me1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(me2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        despliegue.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout despliegueLayout = new javax.swing.GroupLayout(despliegue);
        despliegue.setLayout(despliegueLayout);
        despliegueLayout.setHorizontalGroup(
            despliegueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        despliegueLayout.setVerticalGroup(
            despliegueLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 428, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(Menu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Encabezado, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(MS)
                        .addGap(241, 241, 241))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(despliegue, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Menu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MS)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Encabezado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(despliegue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void reportesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reportesActionPerformed
        ShowJPanelUcontext (new reportes());
    }//GEN-LAST:event_reportesActionPerformed

    private void prestamos1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prestamos1ActionPerformed
        ShowJPanelUcontext (new prestamos());
    }//GEN-LAST:event_prestamos1ActionPerformed

    private void principalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_principalActionPerformed
        ShowJPanelUcontext (new principal());
    }//GEN-LAST:event_principalActionPerformed

    private void DevolucionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DevolucionesActionPerformed
        ShowJPanelUcontext (new devoluciones());
    }//GEN-LAST:event_DevolucionesActionPerformed

    private void librosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_librosActionPerformed
        ShowJPanelUcontext (new libros());
    }//GEN-LAST:event_librosActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Devoluciones;
    private javax.swing.JPanel Encabezado;
    private javax.swing.JLabel MS;
    private javax.swing.JPanel Menu;
    private javax.swing.JPanel despliegue;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton libros;
    private javax.swing.JLabel me1;
    private javax.swing.JLabel me2;
    private javax.swing.JLabel mmi;
    private javax.swing.JLabel mml;
    private javax.swing.JButton prestamos1;
    private javax.swing.JButton principal;
    private javax.swing.JButton reportes;
    // End of variables declaration//GEN-END:variables
}
