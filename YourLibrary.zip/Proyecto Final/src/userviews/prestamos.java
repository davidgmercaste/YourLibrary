
package userviews;

import java.awt.Color;
import javax.swing.JOptionPane;

public class prestamos extends javax.swing.JPanel {

    public prestamos() {
        initComponents();
        initstyles();
    }
    
    private void initstyles(){
        jLabel1.setForeground(Color.BLACK);
        jLabel2.setForeground(Color.BLACK);
        jLabel3.setForeground(Color.BLACK);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        principal = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        image = new javax.swing.JLabel();

        setMaximumSize(new java.awt.Dimension(762, 428));
        setPreferredSize(new java.awt.Dimension(762, 428));

        bg.setBackground(new java.awt.Color(255, 255, 255));
        bg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jSeparator1.setForeground(new java.awt.Color(32, 64, 63));
        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        bg.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 30, 10, 360));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("ID del Libro");
        bg.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 190, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("ID del Usuario");
        bg.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 50, -1, -1));

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        bg.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 220, 270, 50));

        jTextField2.setCaretColor(new java.awt.Color(32, 64, 63));
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        bg.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 80, 270, 50));

        jSeparator2.setForeground(new java.awt.Color(32, 64, 63));
        bg.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 280, 270, 10));

        jSeparator3.setForeground(new java.awt.Color(32, 64, 63));
        bg.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 140, 270, 10));

        principal.setBackground(new java.awt.Color(32, 64, 63));
        principal.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        principal.setForeground(new java.awt.Color(255, 255, 255));
        principal.setText("PRESTAR");
        principal.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 10, 0, 0, new java.awt.Color(49, 69, 73)));
        principal.setBorderPainted(false);
        principal.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        principal.setIconTextGap(0);
        principal.setMaximumSize(new java.awt.Dimension(75, 25));
        principal.setPreferredSize(new java.awt.Dimension(75, 25));
        principal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                principalActionPerformed(evt);
            }
        });
        bg.add(principal, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 300, 240, 70));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Nuevo Prestamo:");
        bg.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 210, 30));

        image.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Downloads\\prestamo.gif")); // NOI18N
        bg.add(image, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 762, 428));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void principalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_principalActionPerformed
       String nombre = jTextField2.getText();
       String id = jTextField1.getText();
        if (nombre.isEmpty()|| id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe llenar todos los campos \n", "Aviso", JOptionPane.ERROR_MESSAGE);
            jTextField2.requestFocus();
            jTextField1.requestFocus();
        }else{
            JOptionPane.showMessageDialog(this, "EL ID DE LIBRO SOLICITADO \nNO EXISTE", "Aviso", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_principalActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bg;
    private javax.swing.JLabel image;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JButton principal;
    // End of variables declaration//GEN-END:variables
}
