
package Exe;

import com.formdev.flatlaf.intellijthemes.FlatGradiantoNatureGreenIJTheme;

public class MAIN {

    public static void main(String args[]) {

        FlatGradiantoNatureGreenIJTheme.setup();
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new loginprincipal().setVisible(true);
            }
        });
    }
    
}
