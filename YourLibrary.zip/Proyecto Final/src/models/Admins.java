
package models;

public class Admins {
    private int id;
    private String usuario;
    private String password;
    
    public void setid(int id) {
        this.id = id;
    }

    public void setUsuario(String name) {
        this.usuario = name;
    }

    public void setPassword(String last_name) {
        this.password = last_name;
    }
    public int getid() {
        return id;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getPassword() {
        return password;
    }
}
