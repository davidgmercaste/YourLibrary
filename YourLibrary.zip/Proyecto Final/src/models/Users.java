
package models;

public class Users {
    private int ID;
    private String Nombre;
    private String Apellido;
    private String SegundoApellido;
    private String NoDocumento;
    private String Telefono;
    //private int sanctions;
    //private int sanc_money;
    

    public void setId(int id) {
        this.ID = id;
    }

    public void setName(String name) {
        this.Nombre = name;
    }

    public void setLast_name(String last_name) {
        this.Apellido = last_name;
    }

    public void setSecond_last_name(String second_last_name) {
        this.SegundoApellido = second_last_name;
    }

    public void setDomicilio(String domicilio) {
        this.NoDocumento = domicilio;
    }

    public void setTel(String tel) {
        this.Telefono = tel;
    }
    
    /**public void setSanctions(int sanctions) {
        this.sanctions = sanctions;
    }

    public void setSanc_money(int sanc_money) {
        this.sanc_money = sanc_money;
    }**/

    public int getId() {
        return ID;
    }

    public String getName() {
        return Nombre;
    }

    public String getLast_name() {
        return Apellido;
    }

    public String getSecond_last_name() {
        return SegundoApellido;
    }

    public String getDomicilio() {
        return NoDocumento;
    }

    public String getTel() {
        return Telefono;
    }
    
    /**public int getSanctions() {
        return sanctions;
    }

    public int getSanc_money() {
        return sanc_money;
    }**/

}
