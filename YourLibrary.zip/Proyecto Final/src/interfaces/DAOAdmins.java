
package interfaces;

import java.util.List;
import models.Admins;

public interface DAOAdmins {
    public void registrar (Admins admin) throws Exception;
    public void modificar (Admins admin) throws Exception;
    public void eliminar (int userID) throws Exception;
    public List<Admins> listar(String name) throws Exception;
    public Admins getAdminById(int adminId) throws Exception;
}

