
package interfaces;

import models.lendings;
import java.util.List;

public interface DAOLendings {
    public void registrar (lendings user) throws Exception;
    public void modificar (lendings user) throws Exception;
    //public void eliminar (lendings user) throws Exception;
    public List<lendings> listar () throws Exception;
}
