
package sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class base {
    
    String bd="yourlibrary";
    String url="jdbc:mysql://localhost:3306/";
    String user="root";
    String password="";
    String driver="com.mysql.cj.jdbc.Driver";
    protected Connection cx;
    
     public Connection conectar(){
        try { 
        Class.forName(driver);
        cx=DriverManager.getConnection(url+bd, user, password);
            System.out.println("Se conectó a bd "+bd);
    } catch (ClassNotFoundException |SQLException ex) {
            System.out.println("No se conectó a bd "+bd);
        }
        return cx;
    }
    
    public void desconectar(){
        try {
            cx.close();
        } catch (SQLException ex) {
            //Logger.getLogger(Logger.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
