
package sql;

import adminviews.adminlogin;
import interfaces.DAOAdmins;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import models.Admins;

public class DAOAdminsImpl extends adminlogin implements DAOAdmins{
    
    @Override
    public void registrar(Admins user) throws Exception {
        try {
            this.conectar();
            PreparedStatement st = this.cx.prepareStatement("INSERT INTO admin(usuario, password) values(?, ?)");
            st.setString(1, user.getUsuario());
            st.setString(2, user.getPassword());
            st.executeUpdate();
        }catch(SQLException e){
            throw e;
        }finally{
            this.desconectar();
        }
    }

    @Override
    public void modificar(Admins user) throws Exception {
        try {
            this.conectar();
            PreparedStatement st = this.cx.prepareStatement("UPDATE admin SET usuario = ?, password = ? WHERE id = ?");
            st.setString(1, user.getUsuario());
            st.setString(2, user.getPassword());
            st.setInt(3, user.getid());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.desconectar();
        }
    }

    @Override
    public void eliminar(int userId) throws Exception {
        try {
            this.conectar();
            PreparedStatement st = this.cx.prepareStatement("DELETE FROM admin WHERE id = ?;");
            st.setInt(1, userId);
            st.executeUpdate();
            st.close();
        }catch(SQLException e){
            throw e;
        }finally{
            this.desconectar();
        }
    }

    @Override
    public List<Admins> listar(String name) throws Exception {
        List<Admins> lista = null;
        try {
           this.conectar();
            String Query = name.isEmpty() ? "SELECT * FROM admin;" : "SELECT * FROM admin WHERE usuario LIKE '%" + name + "%';";
            PreparedStatement st = this.cx.prepareStatement(Query);
            
             lista = new ArrayList();
             ResultSet rs = st.executeQuery();
             while(rs.next()){
                 Admins user = new Admins();
                 user.setid(rs.getInt("id"));
                 user.setUsuario(rs.getString("usuario"));
                 user.setPassword(rs.getString("password"));
                 lista.add(user);
             }
             rs.close();
             st.close();
        }catch (SQLException e){
            throw e;
        }finally {
            this.desconectar();
        }
        return lista;
    }

    @Override
    public Admins getAdminById(int userId) throws Exception {
       Admins user = null;
        try {
            this.conectar();
            PreparedStatement st = this.cx.prepareStatement("SELECT * FROM admin WHERE id = ? LIMIT 1;");
            st.setInt(1, userId);
            
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                user = new Admins();
                user.setid(rs.getInt("id"));
                user.setUsuario(rs.getString("usuario"));
                user.setPassword(rs.getString("password"));
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.desconectar();
        }
        return user; 
    }

    

    
}
