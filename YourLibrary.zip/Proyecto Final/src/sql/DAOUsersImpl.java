
package sql;

import adminviews.adminlogin;
import interfaces.DAOUsers;
import models.Users;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAOUsersImpl extends adminlogin implements DAOUsers{

    @Override
    public void registrar(Users user) throws Exception {
        try {
            this.conectar();
            PreparedStatement st = this.cx.prepareStatement("INSERT INTO users(Nombre, Apellido, SegundoApellido, NoDocumento, Telefono) values(?, ?, ?, ?, ?)");
            st.setString(1, user.getName());
            st.setString(2, user.getLast_name());
            st.setString(3, user.getSecond_last_name());
            st.setString(4, user.getDomicilio());
            st.setString(5, user.getTel());
            st.executeUpdate();
            st.close();
        }catch(SQLException e){
            throw e;
        }finally{
            this.desconectar();
        }
    }

    @Override
    public void modificar(Users user) throws Exception {
        try {
            this.conectar();
            PreparedStatement st = this.cx.prepareStatement("UPDATE users SET Nombre = ?, Apellido = ?, SegundoApellido = ?, NoDocumento = ?, Telefono = ? WHERE ID = ?");
            st.setString(1, user.getName());
            st.setString(2, user.getLast_name());
            st.setString(3, user.getSecond_last_name());
            st.setString(4, user.getDomicilio());
            st.setString(5, user.getTel());
            st.setInt(6, user.getId());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.desconectar();
        }
    }

    @Override
    public void eliminar(int userId) throws Exception {
        try {
            this.conectar();
            PreparedStatement st = this.cx.prepareStatement("DELETE FROM users WHERE id = ?;");
            st.setInt(1, userId);
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.desconectar();
        }
    }

    @Override
    public List<Users> listar(String name) throws Exception {
        List<Users> lista = null;
        try {
           this.conectar();
            String Query = name.isEmpty() ? "SELECT * FROM users;" : "SELECT * FROM users WHERE Nombre LIKE '%" + name + "%';";
            PreparedStatement st = this.cx.prepareStatement(Query);
            
             lista = new ArrayList();
             ResultSet rs = st.executeQuery();
             while(rs.next()){
                 Users user = new Users();
                 user.setId(rs.getInt("ID"));
                 user.setName(rs.getString("Nombre"));
                 user.setLast_name(rs.getString("Apellido"));
                 user.setSecond_last_name(rs.getString("SegundoApellido"));
                 user.setDomicilio(rs.getString("NoDocumento"));
                 user.setTel(rs.getString("Telefono"));
                 //user.setSanctions(rs.getInt("sanctions"));
                 //user.setSanc_money(rs.getInt("sanc_money"));
                 lista.add(user);
             }
             rs.close();
             st.close();
        }catch (SQLException e){
            throw e;
        }finally {
            this.desconectar();
        }
        return lista;
    }

    @Override
    public Users getUserById(int userId) throws Exception {
        Users user = null;
        
        try {
            this.conectar();
            PreparedStatement st = this.cx.prepareStatement("SELECT * FROM users WHERE ID = ? LIMIT 1;");
            st.setInt(1, userId);
            
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                user = new Users();
                user.setId(rs.getInt("ID"));
                user.setName(rs.getString("Nombre"));
                user.setLast_name(rs.getString("Apellido"));
                user.setSecond_last_name(rs.getString("SegundoApellido"));
                user.setDomicilio(rs.getString("NoDocumento"));
                user.setTel(rs.getString("Telefono"));
                //user.setSanctions(rs.getInt("sanctions"));
                //user.setSanc_money(rs.getInt("sanc_money"));
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.desconectar();
        }
        return user;
    }
    
    //@Override
    /**public void sancionar(Users user) throws Exception {
        try {
            this.conectar();
            PreparedStatement st = this.cx.prepareStatement("UPDATE users SET sanctions = ?, sanc_money = ? WHERE ID = ?");
            st.setInt(1, user.getSanctions());
            st.setInt(2, user.getSanc_money());
            st.setInt(3, user.getId());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.desconectar();
        }
    }**/
    
}
