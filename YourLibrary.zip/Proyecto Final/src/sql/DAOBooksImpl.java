
package sql;

import adminviews.adminlogin;
import interfaces.DAOBooks;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import models.Books;

public class DAOBooksImpl extends adminlogin implements DAOBooks{
    @Override
    public void registrar(Books user) throws Exception {
        try {
            this.conectar();
            PreparedStatement st = this.cx.prepareStatement("INSERT INTO libros( titulo, fecha, autor, categoria, edicion, idioma, paginas, stock, disponibilidad) values(?, ?, ?, ?, ?, ?, ?, ?, ?);");
            
            st.setString(1, user.getTitle());
            st.setString(2, user.getDate());
            st.setString(3, user.getAuthor());
            st.setString(4, user.getCategory());
            st.setString(5, user.getEdit());
            st.setString(6, user.getLang());
            st.setString(7, user.getPages());
            st.setString(8, user.getAvailable());
            st.setString(9, user.getStock());
            
            st.executeUpdate();
        }catch(SQLException e){
            throw e;
        }finally{
            this.desconectar();
        }
    }

    @Override
    public void modificar(Books user) throws Exception {
        try {
            this.conectar();
            PreparedStatement st = this.cx.prepareStatement("UPDATE libros set titulo = ?, fecha = ?, autor = ?, categoria = ?, edicion = ?, idioma = ?, paginas = ?, stock = ?, disponibilidad = ?, WHERE ID = ?");
            
            st.setString(1, user.getTitle());
            st.setString(2, user.getDate());
            st.setString(3, user.getAuthor());
            st.setString(4, user.getCategory());
            st.setString(5, user.getEdit());
            st.setString(6, user.getLang());
            st.setString(7, user.getPages());
            st.setString(8, user.getAvailable());
            st.setString(9, user.getStock());
            
            st.executeUpdate();
        }catch(SQLException e){
            throw e;
        }finally{
            this.desconectar();
        }
    }

    @Override
    public void eliminar(int userId) throws Exception {
        try {
            this.conectar();
            PreparedStatement st = this.cx.prepareStatement("DELETE FROM libros WHERE id = ?;");
            st.setInt(1, userId);
            st.executeUpdate();
            st.close();
        }catch(SQLException e){
            throw e;
        }finally{
            this.desconectar();
        }
    }

    @Override
    public List<Books> listar() throws Exception {
        List<Books> lista = null;
        try {
           this.conectar();
            PreparedStatement st = this.cx.prepareStatement("SELECT * FROM libros;");
            lista = new ArrayList();
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                Books user = new Books();
                user.setId(rs.getInt("ID"));
                user.setTitle(rs.getString("titulo"));
                user.setDate(rs.getString("fecha"));
                user.setAuthor(rs.getString("autor"));
                user.setCategory(rs.getString("categoria"));
                user.setEdit(rs.getString("edicion"));
                user.setLang(rs.getString("idioma"));
                user.setPages(rs.getString("paginas"));
                user.setStock(rs.getString("stock"));
                user.setAvailable(rs.getString("disponibilidad"));
                lista.add(user);
            }
            rs.close();
            st.close();
        }catch (SQLException e){
            throw e;
        }finally {
            this.desconectar();
        }
        return lista;
    }
}
